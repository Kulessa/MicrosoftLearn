﻿namespace People;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}
